<?php
/**
 * The template to display the side menu
 *
 * @package WordPress
 * @subpackage TRANSLOGIC
 * @since TRANSLOGIC 1.0
 */
?>
<div class="menu_side_wrap scheme_<?php echo esc_attr(translogic_is_inherit(translogic_get_theme_option('menu_scheme')) 
																	? (translogic_is_inherit(translogic_get_theme_option('header_scheme')) 
																		? translogic_get_theme_option('color_scheme') 
																		: translogic_get_theme_option('header_scheme')) 
																	: translogic_get_theme_option('menu_scheme')); ?>">
	<span class="menu_side_button icon-menu-2"></span>

	<div class="menu_side_inner">
		<?php
		// Logo
		get_template_part( 'templates/header-logo' );
		// Main menu button
		?>
		<div class="toc_menu_item">
			<a href="#" class="toc_menu_description menu_mobile_description"><span class="toc_menu_description_title"><?php esc_html_e('Main menu', 'translogic'); ?></span></a>
			<a class="menu_mobile_button toc_menu_icon icon-menu-2" href="#"></a>
		</div>		
	</div>
	
</div><!-- /.menu_side_wrap -->