WordPress 4.0+ Ready

WordPress 4.0+ Customizer support

WordPress 3+ Custom menu support

Responsive design

Two Color schemes include. Easy colors replacement in WP Customizer

Blog post layout changing – for each page you can choose between:

    Right Sidebar

    Left Sidebar

    Fullwidth

    Wide

    Boxed

Easy logo and favicon replacement

Sociable Icons section in header and Social widget

SEO Ready

Favicon uploader

Swiper slider include

Revolution Slider support

All post formats support

Typography

Audio and Video player for local hosted media included

5+ Custom Widgets

Homepage slider

Easy video including from Youtube and Vimeo   

Social icons section on author’s block

Contact form validator

Comments with reply functionality (multiple levels depth)

Works and looks similar in all major browsers: Internet Explorer, Firefox, Opera, Safari, Google Chrome

Documentation included
